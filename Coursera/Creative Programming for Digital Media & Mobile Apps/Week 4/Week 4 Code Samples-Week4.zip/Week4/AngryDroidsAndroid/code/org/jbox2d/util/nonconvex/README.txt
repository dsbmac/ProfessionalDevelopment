org.jbox2d.util.nonconvex is not currently functional.

Soon, soon...

[Note: it's back again, and appears to work!]